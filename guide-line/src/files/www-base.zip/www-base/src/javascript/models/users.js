jQuery.clss("models.users", {
    init: function(){
        console.log("Hello World!!");
    }
});